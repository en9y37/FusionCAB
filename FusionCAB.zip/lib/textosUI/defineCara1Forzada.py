import adsk.fusion, adsk.core

app = adsk.core.Application.get()

idioma = app.preferences.generalPreferences.userLanguage
#Español = 13
#Ingles = 3

atrib = 'cara1Forzada'

#Textos defineOrientacionEnsamblaje
if idioma == 13:
    tit1 = 'Forzar cara a estar arriba'
else:
    tit1 = 'Force a face to be the top'

if idioma == 13:
    desc1 = 'Fuerza en un componente cuál será la cara de arriba'
else:
    desc1 = "Presets the component to be clamped with this face up"   

if idioma == 13:
    selName1 = 'Selección componente'
else:
    selName1 = 'Component selection'

if idioma == 13:
    selDes1 = 'Elije el componente al que quieras forzar su cara hacia arriba'
else:
    selDes1 = 'Select a component to preset its upper face when clamping'       

if idioma == 13:
    selName2 = 'Posición de la cara de arriba'
else:
    selName2 = 'Top face position'

if idioma == 13:
    selDes2 = 'Elije una cara que represente la superior del componente'
else:
    selDes2 = "Select a face that represents the top"  
 
if idioma == 13:
    ms1 = 'Quedan componentes sin predefinir canto de apoyo.\n¿Quieres establecer los cantos de apoyo de más componentes?'
else:
    ms1 = "Preset clamping for some component not done yet.\nDo you want to preset them?"

if idioma == 13:
    ms2 = 'Este ensamblaje ya tiene posicionamiento definido.\n¿Quieres borrar el posicionamiento y crear uno nuevo?'
else:
    ms2 = 'Assembly clamping already preset.\nDou you want to delete and preset it from scratch?'
    
if idioma == 13:
    ms3 = 'El componente seleccionado no puede ser un ensamblaje'
else:
    ms3 = 'Component selected can not be an assembly'    

if idioma == 13:
    ms4 = 'El posicionamiento de todos los componentes de este ensamblaje se ha completado con éxito'
else:
    ms4 = "The campling preset has been completed succesfully for all the assembly's components"  
 
    
if idioma == 13:
    ms3 = 'El componente seleccionado no puede ser un ensamblaje'
else:
    ms3 = 'Component selected can not be an assembly'    


if idioma == 13:
    ms5 = 'La cara seleccionada corresponde a un canto'
else:
    ms5 = "The selection is an edge"