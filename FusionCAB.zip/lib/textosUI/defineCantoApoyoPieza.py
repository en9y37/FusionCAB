import adsk.fusion, adsk.core

app = adsk.core.Application.get()

idioma = app.preferences.generalPreferences.userLanguage
#Español = 13
#Ingles = 3

atrib = 'cantoApoyoDefinido'

#Textos defineOrientacionEnsamblaje
if idioma == 13:
    tit1 = 'Predefinir posicionamiento de componente'
else:
    tit1 = 'Preset component clamping'

if idioma == 13:
    desc1 = 'Predefine como se posicionará el componente en la máquina'
else:
    desc1 = "Presets how the component will be clamped on the machine"   

if idioma == 13:
    selName1 = 'Selección componente'
else:
    selName1 = 'Component selection'

if idioma == 13:
    selDes1 = 'Elije el componente al que quieras predefinir su posicionamiento'
else:
    selDes1 = 'Select a component to preset its clamping'       

if idioma == 13:
    selName2 = 'Posición del canto delantero'
else:
    selName2 = 'Front edge position'

if idioma == 13:
    selDes2 = 'Elije una cara que represente el canto frontal del componentes'
else:
    selDes2 = "Select a face that represents the front edge of the component"  


if idioma == 13:
    nombregrupo1 = 'Orígenes'
else:
    nombregrupo1 = 'Origins'    
        
if idioma == 13:
    ms1 = 'Queda por establecer el posicionamiento de algunos componentes en este ensamblaje.\n¿Quieres establecer manualmente el posicionamiento de esos componentes?'
else:
    ms1 = "Could not preset clamping for some assembly's component.\nDo you want to preset those componets manually?"

if idioma == 13:
    ms2 = 'Este componente ya tiene posicionamiento definido.\n¿Quieres borrar el posicionamiento y crear uno nuevo?'
else:
    ms2 = 'Assembly clamping already preset.\nDou you want to delete and preset it from scratch?'
    
if idioma == 13:
    ms3 = 'El componente seleccionado no puede ser un ensamblaje'
else:
    ms3 = 'Component selected can not be an assembly'    

if idioma == 13:
    ms4 = 'El posicionamiento de todos los componentes de este ensamblaje se ha completado con éxito'
else:
    ms4 = "The campling preset has been completed succesfully for all the assembly's components" 

if idioma == 13:
    ms5 = 'La cara seleccionada no corresponde a un canto'
else:
    ms5 = "The selection is not an edge"