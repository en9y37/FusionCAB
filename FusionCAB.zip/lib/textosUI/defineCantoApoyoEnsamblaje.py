import adsk.fusion, adsk.core

app = adsk.core.Application.get()

idioma = app.preferences.generalPreferences.userLanguage
#Español = 13
#Ingles = 3

atrib = 'cantoApoyoDefinido'

#Textos defineOrientacionEnsamblaje
if idioma == 13:
    tit1 = 'Predefinir posicionamiento de ensamblaje'
else:
    tit1 = 'Preset assembly clamping'

if idioma == 13:
    desc1 = 'Predefine como se posicionarán en máquina los componentes de un ensamblaje'
else:
    desc1 = "Presets how the assembly's components will be clamped on the machine"   

if idioma == 13:
    selName1 = 'Selección ensamblaje'
else:
    selName1 = 'Assembly selection'

if idioma == 13:
    selDes1 = 'Elije el ensamblaje al que quieras predefinir su posicionamiento'
else:
    selDes1 = 'Select an assembly to preset its components clampings'       

if idioma == 13:
    selName2 = 'Posición del canto delantero'
else:
    selName2 = 'Front edge position'

if idioma == 13:
    selDes2 = 'Elije una cara que represente el canto frontal para todos los componentes del ensamblaje'
else:
    selDes2 = "Select a face that represents the front edge for all the assembly's components"  

if idioma == 13:
    nombregrupo1 = 'Orígenes'
else:
    nombregrupo1 = 'Origins'    
        
if idioma == 13:
    ms1 = 'No se ha podido establecer el posicionamiento de algunos componentes en este ensamblaje.\n¿Quieres establecer manualmente el posicionamiento de esos componentes?'
else:
    ms1 = "Could not preset clamping for some assembly's component.\nDo you want to preset those componets manually?"

if idioma == 13:
    ms2 = 'Este ensamblaje ya tiene posicionamiento definido.\n¿Quieres borrar el posicionamiento y crear uno nuevo?'
else:
    ms2 = 'Assembly clamping already preset.\nDou you want to delete and preset it from scratch?'

if idioma == 13:
    ms3 = 'El elemento seleccionado no es un ensamblaje'
else:
    ms3 = "The selection is not an assembly"